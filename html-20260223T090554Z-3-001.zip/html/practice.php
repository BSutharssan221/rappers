<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>

<pre>

<?php
var_dump(5);
var_dump("John");
var_dump(3.14);
var_dump(true);
var_dump([2, 3, 56]);
var_dump(NULL);
?> 

</pre> 

<?php
echo "Hello World!";
?>

</body>
</html>